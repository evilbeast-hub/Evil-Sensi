
const $ = id => document.getElementById(id);

let platform = "Android";
let busy = false;
let processingInterval = null;

const STORAGE_KEY = "evilSensiSavedProfiles_v2";

// ==================================
// CUSTOM DROPDOWN SYSTEM
// ==================================

function initCustomDropdown(rootId, inputId) {

  const root = $(rootId);
  const hiddenInput = $(inputId);

  const trigger = root.querySelector(".select-trigger");
  const valueText = root.querySelector(".select-value");
  const menu = root.querySelector(".select-menu");
  const options = menu.querySelectorAll(".select-option");

  function closeDropdown() {
    root.classList.remove("open");
    trigger.setAttribute("aria-expanded", "false");
  }

  function selectOption(option) {

    hiddenInput.value = option.dataset.value;
    valueText.textContent = option.textContent;

    options.forEach(item => {
      item.classList.remove("selected");
      item.setAttribute("aria-selected", "false");
    });

    option.classList.add("selected");
    option.setAttribute("aria-selected", "true");

    closeDropdown();

    hiddenInput.dispatchEvent(
      new Event("change", { bubbles: true })
    );
  }

  trigger.addEventListener("click", () => {

    const isOpen = root.classList.contains("open");

    closeAllDropdowns();

    if (!isOpen) {

      root.classList.add("open");

      trigger.setAttribute(
        "aria-expanded",
        "true"
      );

    }

  });

  options.forEach((option, index) => {

    option.addEventListener("click", () => {
      selectOption(option);
    });

    option.addEventListener("keydown", event => {

      if (event.key === "Enter" || event.key === " ") {
        event.preventDefault();
        selectOption(option);
        trigger.focus();
      }

      if (event.key === "ArrowDown") {
        event.preventDefault();

        options[
          (index + 1) % options.length
        ].focus();
      }

      if (event.key === "ArrowUp") {
        event.preventDefault();

        options[
          (index - 1 + options.length) % options.length
        ].focus();
      }

    });

  });

  trigger.addEventListener("keydown", event => {

    if (event.key === "ArrowDown") {

      event.preventDefault();

      closeAllDropdowns();

      root.classList.add("open");

      trigger.setAttribute("aria-expanded", "true");

      options[0].focus();

    }

  });

  return { closeDropdown };

}

function closeAllDropdowns() {

  document.querySelectorAll(".custom-select").forEach(item => {

    item.classList.remove("open");

    item.querySelector(".select-trigger")
      .setAttribute("aria-expanded", "false");

  });

}

initCustomDropdown("ramSelect", "ram");
initCustomDropdown("storageSelect", "storage");

document.addEventListener("click", event => {

  if (!event.target.closest(".custom-select")) {
    closeAllDropdowns();
  }

});

document.addEventListener("keydown", event => {

  if (event.key === "Escape") {
    closeAllDropdowns();
  }

});

// ==================================
// PLATFORM SELECTION
// ==================================

$("androidTab").addEventListener("click", () => {
  setPlatform("Android");
});

$("iosTab").addEventListener("click", () => {
  setPlatform("iOS");
});

function setPlatform(value) {

  if (busy) return;

  platform = value;

  $("androidTab").classList.toggle(
    "active",
    value === "Android"
  );

  $("iosTab").classList.toggle(
    "active",
    value === "iOS"
  );

  $("androidTab").setAttribute(
    "aria-pressed",
    String(value === "Android")
  );

  $("iosTab").setAttribute(
    "aria-pressed",
    String(value === "iOS")
  );

  // Reset device name on platform change
  $("device").value = "";

  $("device").placeholder =
    value === "Android"
      ? "e.g. OPPO A5x 5G"
      : "e.g. iPhone 17 Pro";

  $("formHint").textContent =
    value === "Android"
      ? "Android selected. Enter your Android device details."
      : "iOS selected. Only iPhone models are accepted.";

  validateForm();

}

// ==================================
// DEVICE VALIDATION
// ==================================

function validateDeviceName(name) {

  const normalized = name.trim();

  if (normalized.length < 2) {

    return {
      valid: false,
      message: "Please enter your device model."
    };

  }

  const appleDevice =
    /\b(iphone|ipad|ipod|apple)\b/i.test(normalized);

  if (platform === "Android") {

    if (appleDevice) {

      return {
        valid: false,
        message: "Invalid Android device! iPhone and Apple devices are not allowed."
      };

    }

    return {
      valid: true,
      message: ""
    };

  }

  if (platform === "iOS") {

    const isIphone =
      /^iphone(?:\s|$)/i.test(normalized);

    if (!isIphone) {

      return {
        valid: false,
        message: "Invalid iOS device! Enter an iPhone model, e.g. iPhone 17 Pro."
      };

    }

    return {
      valid: true,
      message: ""
    };

  }

  return {
    valid: false,
    message: "Please select Android or iOS."
  };

}

// ==================================
// DPI SLIDER
// ==================================

$("dpi").addEventListener("input", event => {

  $("dpiValue").textContent = event.target.value;

  validateForm();

});

// ==================================
// FORM VALIDATION
// ==================================

["device", "ram", "storage"].forEach(id => {

  $(id).addEventListener(
    id === "device" ? "input" : "change",
    validateForm
  );

});

function validateForm() {

  const device = $("device").value.trim();

  const deviceCheck = validateDeviceName(device);

  const complete =
    Boolean(platform) &&
    deviceCheck.valid &&
    Boolean($("ram").value) &&
    Boolean($("storage").value);

  $("generateBtn").disabled =
    !complete || busy;

  $("buttonSub").textContent =
    complete
      ? "YOUR DEVICE PROFILE IS READY"
      : "COMPLETE ALL REQUIRED DETAILS FIRST";

  if (!deviceCheck.valid && device.length >= 2) {

    $("formHint").textContent =
      deviceCheck.message;

  } else if (complete) {

    $("formHint").textContent =
      "All details verified. Your device configuration is ready.";

  } else {

    $("formHint").textContent =
      platform === "Android"
        ? "Select Android and enter your device model, RAM and storage."
        : "Select iOS and enter your iPhone model, RAM and storage.";

  }

}

// ==================================
// SCREEN NAVIGATION
// ==================================

function show(screen) {

  [
    "formScreen",
    "processingScreen",
    "resultScreen"
  ].forEach(id => {

    $(id).classList.toggle(
      "hidden",
      id !== screen
    );

  });

  $("generateBtn").classList.toggle(
    "hidden",
    screen !== "formScreen"
  );

  window.scrollTo({
    top: 0,
    behavior: "smooth"
  });

}

// ==================================
// HASH GENERATOR
// ==================================

function hashString(text) {

  let hash = 2166136261;

  for (let i = 0; i < text.length; i++) {

    hash ^= text.charCodeAt(i);

    hash = Math.imul(
      hash,
      16777619
    );

  }

  return hash >>> 0;

}

function seededNumber(seed, min, max) {

  return (
    (seed % (max - min + 1)) + min
  );

}

// ==================================
// LOCAL STORAGE
// ==================================

function readProfiles() {

  try {

    const data = JSON.parse(
      localStorage.getItem(STORAGE_KEY) || "{}"
    );

    return data &&
      typeof data === "object" &&
      !Array.isArray(data)
        ? data
        : {};

  } catch (error) {

    console.warn("Profile reading error:", error);

    return {};

  }

}

function saveProfiles(profiles) {

  try {

    localStorage.setItem(
      STORAGE_KEY,
      JSON.stringify(profiles)
    );

    return true;

  } catch (error) {

    console.warn("Profile saving error:", error);

    return false;

  }

}

// ==================================
// CREATE DEVICE PROFILE
// ==================================

function createProfile(
  device,
  ram,
  preferredDpi,
  preferences
) {

  const normalizedDevice = device
    .trim()
    .toLowerCase()
    .replace(/\s+/g, " ");

  const seed = hashString(
    `${platform}|${normalizedDevice}|${ram}`
  );

  const ramNumber = Number(ram);

  const ramAdjustment = Math.round(
    (ramNumber - 4) * 1.4
  );

  const base =
    seededNumber(seed, 174, 190) +
    ramAdjustment;

  const general = Math.max(
    120,
    Math.min(200, base)
  );

  const profileDpi = Math.max(
    360,
    Math.min(
      999,
      Math.round(
        (
          preferredDpi +
          ((seed % 31) - 15) +
          (ramNumber - 4) * 2
        ) / 5
      ) * 5
    )
  );

  // Preference adjustments
  const headshotAdjustment =
    preferences.headshot ? 2 : 0;

  const steadyAdjustment =
    preferences.steady ? 3 : 0;

  return {

    general,

    red: Math.max(
      100,
      Math.min(
        200,
        general -
        seededNumber(seed >>> 2, 4, 10) +
        headshotAdjustment
      )
    ),

    scope2: Math.max(
      90,
      general -
      seededNumber(seed >>> 3, 14, 22) -
      steadyAdjustment
    ),

    scope4: Math.max(
      80,
      general -
      seededNumber(seed >>> 4, 25, 36) -
      steadyAdjustment
    ),

    sniper: Math.max(
      50,
      general -
      seededNumber(seed >>> 5, 42, 55)
    ),

    free: Math.max(
      90,
      general -
      seededNumber(seed >>> 6, 8, 16)
    ),

    dpi: profileDpi,

    fire: seededNumber(seed >>> 7, 48, 55),

    graphics: preferences.fps
      ? "Highest stable FPS available"
      : "Balanced graphics",

    createdAt: new Date().toISOString()

  };

}

// ==================================
// DISPLAY RESULT
// ==================================

function displayProfile(
  profile,
  device,
  ram,
  storage,
  wasSaved,
  wasPersisted
) {

  $("general").textContent = profile.general;

  $("red").textContent = profile.red;

  $("scope2").textContent = profile.scope2;

  $("scope4").textContent = profile.scope4;

  $("sniper").textContent = profile.sniper;

  $("free").textContent = profile.free;

  $("resultDpi").textContent = profile.dpi;

  $("fire").textContent = profile.fire + "%";

  $("graphics").textContent =
    profile.graphics || "Balanced graphics";

  $("resultDevice").textContent =
    device.toUpperCase();

  $("resultMeta").textContent =
    `${platform} • ${ram} GB RAM • ${storage}`;

  if (!wasPersisted) {

    $("resultStatus").textContent =
      "✓ CONFIGURATION READY • NOT SAVED";

  } else if (wasSaved) {

    $("resultStatus").textContent =
      "✓ PREVIOUS PROFILE RESTORED";

  } else {

    $("resultStatus").textContent =
      "✓ NEW PROFILE SAVED";

  }

}

// ==================================
// PROCESSING ANIMATION
// ==================================

function startProcessing(duration, callback) {

  const progressBar = $("progressBar");
  const progressText = $("progressText");

  const startTime = Date.now();

  progressBar.style.width = "0%";
  progressText.textContent = "0%";

  if (processingInterval) {
    clearInterval(processingInterval);
  }

  processingInterval = setInterval(() => {

    const elapsed = Date.now() - startTime;

    const progress = Math.min(
      100,
      Math.floor((elapsed / duration) * 100)
    );

    progressBar.style.width =
      progress + "%";

    progressText.textContent =
      progress + "%";

    if (elapsed >= duration) {

      clearInterval(processingInterval);

      processingInterval = null;

      callback();

    }

  }, 100);

}

// ==================================
// MAIN GENERATE FUNCTION
// ==================================

function generate() {

  validateForm();

  if (
    $("generateBtn").disabled ||
    busy
  ) {
    return;
  }

  const device = $("device").value.trim();

  const ram = $("ram").value;

  const storage = $("storage").value;

  const dpi = Number($("dpi").value);

  const deviceCheck = validateDeviceName(device);

  if (!deviceCheck.valid) {

    $("formHint").textContent =
      deviceCheck.message;

    return;

  }

  const normalizedDevice = device
    .toLowerCase()
    .replace(/\s+/g, " ");

  // Each platform + device + RAM + storage
  // gets its own saved profile.

  const profileKey = [
    platform,
    normalizedDevice,
    ram + "GB",
    storage
  ].join("|");

  const preferences = {

    fps: $("fps").checked,

    headshot: $("headshot").checked,

    steady: $("steady").checked

  };

  busy = true;

  $("generateBtn").disabled = true;

  show("processingScreen");

  // Random processing time between 10 and 15 seconds

  const processingTime =
    Math.floor(Math.random() * 5001) + 10000;

  startProcessing(processingTime, () => {

    const profiles = readProfiles();

    let profile = profiles[profileKey];

    const wasSaved = Boolean(profile);

    let wasPersisted = true;

    // Create only if profile does not already exist

    if (!profile) {

      profile = createProfile(
        device,
        ram,
        dpi,
        preferences
      );

      profiles[profileKey] = profile;

      wasPersisted = saveProfiles(profiles);

    }

    displayProfile(
      profile,
      device,
      ram,
      storage,
      wasSaved,
      wasPersisted
    );

    busy = false;

    show("resultScreen");

    validateForm();

  });

}

// ==================================
// BUTTON EVENTS
// ==================================

$("generateBtn").addEventListener(
  "click",
  generate
);

$("backBtn").addEventListener("click", () => {

  if (busy) return;

  show("formScreen");

  validateForm();

});

// ==================================
// INITIAL SETTINGS
// ==================================

// Automatically select Android

setPlatform("Android");

// Default DPI display

$("dpiValue").textContent =
  $("dpi").value;

// Initial validation

validateForm();
